#!/bin/bash
/usr/bin/java -Xmx2g -DLOG_FILENAME="logs/logchecker" -Dlogback.configurationFile=logback.xml -jar ./CheckerChallenge-1.2.0.jar data/instances.csv
