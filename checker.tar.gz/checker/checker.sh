#!/bin/bash
/usr/bin/java -Xmx2g -DLOG_FILENAME="logs/logchecker" -Dlogback.configurationFile=logback.xml -jar ./CheckerChallenge-1.5.1.jar instances.csv
