#!/bin/bash
/usr/bin/java -Xmx2g -DLOG_FILENAME="logs/logchecker" -Dlogback.configurationFile=logback.xml -jar ./CheckerChallenge-1.3.0.jar instances.csv
