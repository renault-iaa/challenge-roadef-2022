#!/bin/bash
/usr/bin/java -Xmx1g -DLOG_FILENAME="logs/logchecker" -Dlogback.configurationFile=logback.xml -jar ./CheckerChallenge-1.9.0.jar instances.csv
