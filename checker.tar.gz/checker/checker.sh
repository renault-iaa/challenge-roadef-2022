#!/bin/bash
/usr/bin/java -Xmx4g -DLOG_FILENAME="logs/logchecker" -Dlogback.configurationFile=logback.xml -jar ./CheckerChallenge-1.10.0.jar instances.csv
